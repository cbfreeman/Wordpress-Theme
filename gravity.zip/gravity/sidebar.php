<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package Gravity
 * @since Gravity 1.0
 */
?>
		
<div id="secondary" class="widget-area" role="complementary">
			<?php do_action( 'before_sidebar' ); ?>
			<?php if ( ! dynamic_sidebar( 'sidebar-1' ) ) : ?>

				<aside id="search" class="widget widget_search">
					<?php get_search_form(); ?>
				</aside>

				<aside id="archives" class="widget">
					<h1 class="widget-title"><?php _e( 'Archives', 'gravity' ); ?></h1>
					<ul>
						<?php wp_get_archives( array( 'type' => 'monthly' ) ); ?>
					</ul>
				</aside>

				<aside id="meta" class="widget">
					<h1 class="widget-title"><?php _e( 'Meta', 'gravity' ); ?></h1>
					<ul>
						<?php wp_register(); ?>
						<li><?php wp_loginout(); ?></li>
						<?php wp_meta(); ?>
					</ul>
				</aside>

			<?php endif; // end sidebar widget area ?>
		</div><!-- #secondary .widget-area -->


	<div id="tertiary" class="widget-area" role="complementary">
			<?php do_action( 'before_sidebar' ); ?>
			<?php if ( ! dynamic_sidebar( 'sidebar-2' ) ) : ?>

				<aside id="archives" class="widget">
					<h1 class="widget-title"><?php _e( 'Archives', 'gravity' ); ?></h1>
					<ul>
						<?php wp_get_archives( array( 'type' => 'monthly' ) ); ?>
					</ul>
				</aside>

				
			<?php endif; // end sidebar widget area ?>
		</div><!-- #tertiary .widget-area -->


<div id="cinco" class="widget-area" role="complementary">
										
			<?php do_action( 'before_sidebar' ); ?>
			
			
				<aside id="archives" class="widget">
<h2 class="widget-title">Connect</h2>

</aside>


			
		</div><!-- #cinco .widget-area -->
<div id="recent-posts-title"><h3>Recent Projects</h3></div>
<div id="midsection-divider"></div>	
<div id="recent-posts" class="posts-content" role="complementary">
								
			<?php echo gravity_recentPosts(); ?>
		</div><!-- #recent-posts .widget-area -->
<div id="section-divider"></div>
<div id="section-divider2"></div>
