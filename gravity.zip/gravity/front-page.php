<?php
/**
 * Template Name: Front Page
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package Gravity
 * @since Gravity 1.0
 */
get_header('front');?>
<div id="front-page"></div>
		<div id="primary-front" class="content-area"></div><!-- #primary .content-area -->
			<div id="content-front" class="site-content" role="main">

<section id="featured-slider">
	<div id="slides">
		<div class="slides_container">
			
			<?php 
				$loop = new WP_Query( array( 'post_type' => 'feature', 'posts_per_page' => -1, 'orderby'=> 'ASC' ) ); 
			?>
			<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

				<div class="slide">
					<?php $url = get_post_meta($post->ID, "url", true);/*If the custom field has a link, add a link to image */
					if($url!='') { 
						echo '<a href="'.$url.'">';
						echo the_post_thumbnail('full');
						echo '</a>';
					} else { /* If the custom field is empty, just display the image */
						echo the_post_thumbnail('full');
					} ?>
									</div>

			<?php endwhile; ?>		
			<?php wp_reset_postdata(); ?>

		</div>
		<a href="#" class="prev">prev</a>
		<a href="#" class="next">next</a>
	</div>
</section>

				<?php while ( have_posts() ) : the_post(); ?>

					

					
				<?php endwhile; // end of the loop. ?>

			</div><!-- #content .site-content -->
		

<?php get_sidebar(); ?>

<?php get_footer(); ?>
