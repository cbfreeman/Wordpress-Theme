<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package Gravity
 * @since Gravity 1.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<h4 class="entry-title"><?php the_title(); ?></h2>
		
	
<div class="featured-image">
<?php if ( has_post_thumbnail() ) {

the_post_thumbnail('featured-thumbnail', array('class' => 'alignleft')); 
} else { ?>

<img src="<?php bloginfo('template_directory'); ?>/images/default-image.png" alt="<?php the_title(); ?>" />

<?php } ?>
</div>
<div class="entry-meta">
			
		</div><!-- .entry-meta -->
	</header><!-- .entry-header -->
	<div class="entry-content">
		<?php the_content(); ?>
		<?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', 'gravity' ), 'after' => '</div>' ) ); ?>
		<?php edit_post_link( __( 'Edit', 'gravity' ), '<span class="edit-link">', '</span>' ); ?>
	</div><!-- .entry-content -->
</article><!-- #post-<?php the_ID(); ?> -->