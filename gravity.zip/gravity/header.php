<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package Gravity
 * @since Gravity 1.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width" />
<!-- Title -->
<title> <?php wp_title('|', true, 'left'); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<!--[if lt IE 9]>
<script src="<?php echo bloginfo(); ?>/js/html5.js" type="text/javascript"></script>
<![endif]-->

<script src="<?php echo bloginfo(); ?>/js/main-slider.js" type="text/javascript"></script>

<?php wp_head(); ?>

</head>

<body <?php body_class(); ?>>

<div id="search_box">
<?php get_search_form(); ?></div>

<div id="page" class="hfeed site">
<!-- self portrait -->
<div id="portrait">
<?php $header_image = get_header_image();
        if ( ! empty( $header_image ) ) { ?>
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
                <img src="<?php header_image(); ?>" width="<?php echo get_custom_header()->width; ?>" height="<?php echo get_custom_header()->height; ?>" alt="" />
            </a>
<?php } // if ( ! empty( $header_image ) ) 
?>
</div>

	<?php do_action( 'before' ); ?>
	<header id="masthead" class="site-header" role="banner">
		<hgroup>

			<div id="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></div>
			<div class="site-description"><?php bloginfo( 'description' ); ?></div>
		</hgroup>

		<nav role="navigation" class="site-navigation main-navigation">
			<div id="menu-primary">
<?php wp_nav_menu( array( 'theme_location' => 'header-menu' ) ); ?>
</div>


</nav><!-- .site-navigation .main-navigation -->

	</header><!-- #masthead .site-header -->

	<div id="main" class="site-main">
<section id="featured-slider">
	<div id="slides">
		<div class="slides_container">
			
			<?php 
				$loop = new WP_Query( array( 'post_type' => 'feature', 'posts_per_page' => -1, 'orderby'=> 'ASC' ) ); 
			?>
			<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

				<div class="slide">
					<?php $url = get_post_meta($post->ID, "url", true);/*If the custom field has a link, add a link to image */
					if($url!='') { 
						echo '<a href="'.$url.'">';
						echo the_post_thumbnail('full');
						echo '</a>';
					} else { /* If the custom field is empty, just display the image */
						echo the_post_thumbnail('full');
					} ?>
									</div>

			<?php endwhile; ?>		
			<?php wp_reset_postdata(); ?>

		</div>
		<a href="#" class="prev">prev</a>
		<a href="#" class="next">next</a>
	</div>
</section>
<div id="midsection"></div>

