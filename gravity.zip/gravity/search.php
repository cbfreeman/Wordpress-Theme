<?php
/**
 * The template for displaying Search Results pages.
 *
 * @package Gravity
 * @since Gravity 1.0
 */

get_header(); ?>

		<section id="primary" class="content-area">
			<div id="content" class="site-content" role="main">

			<?php if ( have_posts() ) : ?>

				<header class="page-header">
					<h4 class="page-title"><?php printf( __( 'Search Results for: %s', 'gravity' ), '<span>' . get_search_query() . '</span>' ); ?></h4>
<?php the_post_thumbnail(); ?>

				</header><!-- .page-header -->

				<?php gravity_content_nav( 'nav-above' ); ?>

				<?php /* Start the Loop */ ?>
				<?php while ( have_posts() ) : the_post(); ?>

					<?php get_template_part( 'content', 'search' ); ?>

				<?php endwhile; ?>

				<?php gravity_content_nav( 'nav-below' ); ?>

			<?php else : ?>

				<?php get_template_part( 'no-results', 'search' ); ?>
<h4 class="page-title">WAIT A MINUTE
WE CAN&rsquo;T FIND THE PAGE <br>YOU ARE LOOKING FOR -- SORRY.</h4>

			<?php endif; ?>

			</div><!-- #content .site-content -->
		</section><!-- #primary .content-area -->

<?php get_template_part('footer-page'); ?>
</div>
