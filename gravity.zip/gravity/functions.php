<?php
/*
 * @package Gravity
 * @subpackage Functions
 * @version 1.0
 * @author Craig Freeman
 * @link http://cbfreeman.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html
 */

/**
 * Set the content width based on the theme's design and stylesheet.
 *
 * @since Gravity 1.0
 */
if ( ! isset( $content_width ) )
    $content_width = 654; /* pixels */


if ( ! function_exists( 'gravity_setup' ) ):
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which runs
 * before the init hook. The init hook is too late for some features, such as indicating
 * support post thumbnails.
 *
 * @since gravity 1.0
 */
function gravity_setup() {
 
    /**
     * Custom template tags for this theme.
     */
    require( get_template_directory() . '/inc/template-tags.php' );
 
    /**
     * Custom functions that act independently of the theme templates
     */
    require( get_template_directory() . '/inc/tweaks.php' );
 
    /**
     * Make theme available for translation
     * Translations can be filed in the /languages/ directory
     */
    load_theme_textdomain( '_s', get_template_directory() . '/languages' );
 
load_theme_textdomain('_s');

    /**
     * Add default posts and comments RSS feed links to head
     */
    add_theme_support( 'automatic-feed-links' );
 
    /**
     * Enable support for the Aside Post Format
     */
    add_theme_support( 'post-formats', array( 'aside' ) );
 
    
}
endif; // gravity_setup
add_action( 'after_setup_theme', 'gravity_setup' );
/**
 * Register widgetized area and update sidebar with default widgets
 *
 * @since gravity 1.0
 */
function gravity_widgets_init() {
    register_sidebar( array(
        'name' => __( 'Primary Widget Area', 'gravity' ),
        'id' => 'sidebar-1',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ) );
 
    register_sidebar(array(
		'name'=> __( 'Secondary Widget ', 'gravity' ),
		'id' => 'sidebar-2',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<h2 class="widget-title">',
		'after_title' => '</h3>',
	));
	register_sidebar(array(
		'name'=> __('Third Widget Area', 'gravity' ),
		'id' => 'sidebar-3',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<h2 class="widget-title">',
		'after_title' => '</h2>',
	));

}
add_action( 'widgets_init', 'gravity_widgets_init' );
/**
 * Enqueue scripts and styles
 */
function gravity_scripts() {
    wp_enqueue_style( 'style', get_stylesheet_uri() );
 
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
 
    wp_enqueue_script( 'small-menu', get_template_directory_uri() . '/js/small-menu.js', array( 'jquery' ), '20120206', true );
 
    if ( is_singular() && wp_attachment_is_image() ) {
        wp_enqueue_script( 'keyboard-image-navigation', get_template_directory_uri() . '/js/keyboard-image-navigation.js', array( 'jquery' ), '20120202' );
    }
}
add_action( 'wp_enqueue_scripts', 'gravity_scripts' );


if ( function_exists( 'add_theme_support' ) ) { 
add_theme_support( 'post-thumbnails' );
set_post_thumbnail_size( 250, 250, true ); // default Post Thumbnail dimensions (cropped)

// additional image sizes
// delete the next line if you do not need additional image sizes

add_image_size( 'attachment-thumbnail', 75, 75, true ); 
add_image_size( 'recent-thumbnail', 250, 200, true ); 
add_image_size( 'archive-thumbnail', 625,229, true ); 
add_image_size( 'single-thumbnail', 125, 125, true ); 
add_image_size( 'featured-thumbnail', 625, 229, true, array('class' => 'featured')); 
add_image_size( 'slider-nav-thumbnail', 110, 70, true ); 
}

add_theme_support( 'custom-background' );


//custom stylesheet
add_editor_style('style.css');

/**
 * Implement the Custom Header feature
 */
require( get_template_directory() . '/inc/custom-header.php' );

function register_my_menus() {
  register_nav_menus(
    array( 'header-menu' => __( 'Header Menu', 'gravity' ) )
  );
}
add_action( 'init', 'register_my_menus' );

?>


<?php
add_action( 'after_setup_theme', 'blm_theme_setup' );
function blm_theme_setup() {

	global $content_width;
	/* Set the $content_width for things such as video embeds. */
	if ( !isset( $content_width ) )
	$content_width = 654;

	/* Add theme support for automatic feed links. */
	add_theme_support( 'automatic-feed-links' );

	/* Add theme support for post thumbnails (featured images). */
	add_theme_support( 'post-thumbnails');
}



function blm_register_sidebars() {
	register_sidebar(
		array(
			'id' => 'primary',
			'name' => __( 'Primary Sidebar', 'gravity' ),
			'description' => __( 'The following widgets will appear in the main sidebar div.', 'gravity' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget' => '</aside>',
			'before_title' => '<h4>',
			'after_title' => '</h4>'
		)
	);
}


function blm_init_method() {

	wp_enqueue_script('jquery');
	wp_enqueue_script( 'slides', get_template_directory_uri().'/js/slides.min.jquery.js', array( 'jquery' ) );

	}
add_action('wp_enqueue_scripts', 'blm_init_method');


// Custom Post types for Feature project on home page 
	   add_action('init', 'create_feature');
	     function create_feature() {
	       $feature_args = array(
	          'labels' => array(
	           'name' => __( 'Feature Project', 'gravity' ),
	           'singular_name' => __( 'Feature Project', 'gravity' ),
	           'add_new' => __( 'Add New Feature Project', 'gravity' ),
	           'add_new_item' => __( 'Add New Feature Project', 'gravity' ),
	           'edit_item' => __( 'Edit Feature Project', 'gravity' ),
	           'new_item' => __( 'Add New Feature Project', 'gravity' ),
	           'view_item' => __( 'View Feature Project', 'gravity' ),
	           'search_items' => __( 'Search Feature Project', 'gravity' ),
	           'not_found' => __( 'No feature project found', 'gravity' ),
	           'not_found_in_trash' => __( 'No feature project found in trash', 'gravity' )
	         ),
	       'public' => true,
	       'show_ui' => true,
	       'capability_type' => 'post',
	       'hierarchical' => false,
	       'rewrite' => true,
	       'menu_position' => 20,
	       'supports' => array('title', 'editor', 'thumbnail')
	     );
	  register_post_type('feature',$feature_args);
	}
	add_filter("manage_feature_edit_columns", "feature_edit_columns");

	function feature_edit_columns($feature_columns){
	   $feature_columns = array(
	      "cb" => "<input type=\"checkbox\" />",
	      "title" => "Title",
	   );
	  return $feature_columns;
	}


	//Add Meta Boxes
	
	add_action( 'add_meta_boxes', 'cd_meta_box_add' );
	function cd_meta_box_add()
	{
		add_meta_box( 'my-meta-box-id', 'Link to Project', 'cd_meta_box_cb', 'feature', 'normal', 'high' );
	}

	function cd_meta_box_cb( $post )
	{
		$url = get_post_meta($post->ID, 'url', true);
		wp_nonce_field( 'my_meta_box_nonce', 'meta_box_nonce' ); ?>

		<p>
			<label for="url">Project url</label>
			<input type="text" name="url" id="url" value="<?php echo $url; ?>" style="width:350px" />
		</p>

		<?php	
	}

	add_action( 'save_post', 'cd_meta_box_save' );
	function cd_meta_box_save( $post_id )
	{
		// Bail if we're doing an auto save
		if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

		// if our nonce isn't there, or we can't verify it, bail
		if( !isset( $_POST['meta_box_nonce'] ) || !wp_verify_nonce( $_POST['meta_box_nonce'], 'my_meta_box_nonce' ) ) return;

		// if our current user can't edit this post, bail
		if( !current_user_can( 'edit_post' ) ) return;

		// now we can actually save the data
		$allowed = array( 
			'a' => array( // on allow a tags
				'href' => array() // and those anchors can only have href attribute
			)
		);

		// Probably a good idea to make sure your data is set
		if( isset( $_POST['url'] ) )
			update_post_meta( $post_id, 'url', wp_kses( $_POST['url'], $allowed ) );
	}

function recentPosts() {

    $rPosts = new WP_Query();

    $rPosts->query('showposts=3');

        while ($rPosts->have_posts()) : $rPosts->the_post(); ?>
<ul>
            <li class="quad-thumbnail">
<center>
                <a href="<?php the_permalink();?>"><?php the_post_thumbnail('recent-thumbnail'); ?></a></center>
</li>
<li><?php the_excerpt();?></li>
</ul>
        <?php endwhile; 

    wp_reset_query();

}

function new_excerpt_length($length) {
    return 20;
}
add_filter('excerpt_length', 'new_excerpt_length');


/*
 * Returns a shortened $content with '...' appended to the end. Also
 * removes any breaks in the content
 * 
 * todo: ensure we do not cut off html tags part way through and break the theme
 */
function shorten_content($content, $size)
{
  //$content = preg_replace("/(\<br\/\>)|(\<br\>)|(\<br \/\>)/", " ", $content);
  $content = strip_tags($content);
  if(strlen($content) < $size)
    return $content;
    
  $content = substr($content, 0, $size);
  $spaceloc = strrpos($content, " ");
  if($spaceloc)
  {
    $content = substr($content, 0, $spaceloc);
    $content.= "...";
  }
  return $content;
}


/* a custom callback function that displays a meaningful title
 * depending on the page being rendered
 */
function gravity_filter_wp_title($title, $sep, $sep_location) {
 
  // add white space around $sep
  $sep = ' ' . $sep . ' ';
 
  $site_description = get_bloginfo('description');
 
  if ($site_description && (is_home() || is_front_page()))
      $custom = $sep . $site_description;
 
  elseif(is_category())
      $custom = $sep . __('Category', 'gravity');
 
  elseif(is_tag())
      $custom = $sep . __('Tag', 'gravity');
 
  elseif(is_author())
      $custom = $sep . __('Author', 'gravity');
 
  elseif(is_year() || is_month() || is_day())
      $custom = $sep . __('Archives', 'gravity');
 
  else
      $custom = '';
 
  // get the page number (main page or an archive)
  if(get_query_var('paged'))
    $page_number = $sep . __('Page ', 'gravity') . get_query_var('paged');
 
  // get the page number (post with multipages)
  elseif(get_query_var('page'))
    $page_number = $sep . __('Page ', 'gravity') . get_query_var('page');
 
  else
    $page_number = '';
 
  // Comment the 4 lines of code below and see how odd the title format becomes
  if($sep_location == 'right' && !(is_home() || is_front_page())) {
      $custom = $custom . $sep;
      $title = substr($title, 0, -2);
  }
 
  // return full title
  return get_bloginfo('name') . $custom . $title . $page_number;
 
} // end of function gravity_filter_wp_title
 
/* add function 'gravity_filter_wp_title()' to the
 * wp_title filter, with priority 10 and 3 args
 */
add_filter('wp_title', 'gravity_filter_wp_title', 10, 3);



function display_images_in_list($size = full) {

	if($images = get_posts(array(
		'post_parent'    => get_the_ID(),
		'post_type'      => 'attachment',
		'numberposts'    => -1, // show all
		'post_status'    => null,
		'post_mime_type' => 'image',
                'orderby'        => 'menu_order',
                'order'           => 'ASC',
	))) {
		foreach($images as $image) {
			$attimg   = wp_get_attachment_image($image->ID,$size);

echo $attimg;

		}
	}
}


?>