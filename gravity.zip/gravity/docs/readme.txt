Gravity Theme

WordPress Theme

Gravity is a modern theme with fixed layout.The theme is built to utilize the core WordPress functions for image and media library management. No third-party plugins are used to store, organize, or present the content. The modern design and well-organized coding make it an excellent starting point for further customization and development.


FEATURES

Simple, image-centric Design
Modular, fixed layout
Featured content slider
Custom front page template
One main menu
Advanced widgets
Theme settings
Breadcrumbs
Custom Header
Custom background
Child-theme friendly
Translation-ready (contains .po/.mo files)

INSTALLATION & USAGE

The following steps will teach you how to achieve the structure of the Gravity demo site. You will also learn the specifics of the theme, which aren't really that much - it's made to be as intuitive as possible.

Login to your WordPress admin panel and navigate to "Pages" -> "Add New". Fill in a page title - 'Home' for example (doesn't really matter) and then click the "Template" dropdown list. Select "Front Page" and then click the "Publish" button.

Go to "Settings" -> "Reading" and set the front page to display a static page -> from the "Front Page" dropdown list select the title of the page we created in the previous step. In my case that was "Home'.

Start adding posts to your site from "Posts" ->"Add New". Write title, text, images, video, etc. Choose category(- ies) and tags for the post. Then look at the bottom right panel and set a "Featured Image".

Menus. Gravity supports only one menu. Navigate to "Appearance" -> "Menus" to set it up.

Featured Project. a special section to be used for the content of the featured content slider. Navigate to "Featured Project" -> "Add new Feature Project". All featured images added will be part of the front-page slider. After all is done, there is just one final step - specific for this theme�

Custom Header. To add the sitewide image that shows up at the top left of ALL pages. Navigate to "Appearance" -> "Header" -> upload your image.

Twitter Widget. To properly configure this widget to display your Twitter account Navigate to "Appearance" -> "Editor" -> "Sidebar". Replace the following with your twitter account details -> screen_name="yourusername".


Thats it - your done!


The theme uses a couple of fonts that are released under GPL-compatible licenses:

Google Fonts (Droid) - licensed under OFL.
COPYRIGHT & LICENSE

Gravity is licensed under the GNU General Public License, version 2 (GPL).

This theme is copyrighted to Craig Freeman.