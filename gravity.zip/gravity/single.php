<?php
/**
 * The Template for displaying all single posts.
 *
 * @package Gravity
 * @since Gravity 1.0
 */

get_header(); ?>
<div id="site-page">
<div class="icon-date">
                 <h3><?php echo get_the_date('M j Y'); ?></h3>
</div><!--icon-date -->


		<div id="primary" class="content-area">
			<div id="content" class="site-content" role="main">

			<?php while ( have_posts() ) : the_post(); ?>



				<?php get_template_part( 'content', 'single' ); ?>

				<?php gravity_content_nav( 'nav-below' ); ?>

							<?php endwhile; // end of the loop. ?>


			</div><!-- #content .site-content -->
		</div><!-- #primary .content-area -->


<?php get_template_part('footer-page'); ?>
</div>
